<?php

namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Category;
use App\Models\Blog;
use Illuminate\Support\Str;

use Illuminate\Http\Request;

class HomeController extends Controller {
    public function index() {

        $parentCategories = Product::where( 'status', 'A' )

        ->select( 'parent_cat' )

        ->distinct()

        ->pluck( 'parent_cat' );

        $productTabs = [];

        // Featured Tab

        $productTabs[ 'featured' ] = [

            'label' => 'Featured',

            'products' => Product::where( 'status', 'A' )

            ->inRandomOrder()

            ->limit( 10 )

            ->get(),

        ];

        // Dynamic Tabs

        foreach ( $parentCategories as $parentCat ) {

            $key = Str::slug( $parentCat, '_' );

            $productTabs[ $key ] = [

                'label' => $parentCat,

                'products' => Product::where( 'status', 'A' )

                ->where( 'parent_cat', $parentCat )

                ->limit( 10 )

                ->get(),

            ];

        }

        // suggested products
        $suggestedProducts = Product::where( 'status', 'A' )
        ->inRandomOrder()
        ->limit( 15 )
        ->get();

        //blogs-list-random---
        $blogPosts = Blog::where( 'status', 'A' )
            ->inRandomOrder()
            ->limit( 3 )
            ->get();

        // dd([
        //     'page' => 'Home page',
        //     'route' => url('/'),
        //     'blogs' => $blogPosts->map(fn (Blog $blog) => $this->blogImageDebugData($blog))->values()->all(),
        // ]);

        return view( 'home.index', compact( 'productTabs', 'suggestedProducts', 'blogPosts' ) );

    }

    private function blogImageDebugData(Blog $blog): array
    {
        $images = collect([$blog->image1, $blog->image2, $blog->image3])
            ->filter()
            ->values();

        $resolved = $images->mapWithKeys(function ($image) {
            $image = ltrim((string) $image, '/');
            $candidates = str_starts_with($image, 'assets/')
                ? [$image]
                : [$image, 'assets/images/blog/' . $image];
            $path = collect($candidates)->first(fn ($candidate) => file_exists(public_path($candidate)));

            return [$image => $path ? asset($path) : null];
        });

        return [
            'id' => $blog->id,
            'heading' => $blog->heading,
            'slug' => $blog->slug,
            'db_images' => $images->all(),
            'resolved_urls' => $resolved->filter()->values()->all(),
            'missing_images' => $resolved->filter(fn ($url) => $url === null)->keys()->all(),
        ];
    }
}
